/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: 60cd531d36a34fe7c51982e9ec40b45d2a2a4ce7 */

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_apache_request_headers, 0, 0, IS_ARRAY, 0)
ZEND_END_ARG_INFO()

#define arginfo_apache_response_headers arginfo_apache_request_headers

#define arginfo_getallheaders arginfo_apache_request_headers
