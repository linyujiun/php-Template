/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: ee776e0c54fe4b66a98b3a0203af11c5f3082e38 */

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_cli_set_process_title, 0, 1, _IS_BOOL, 0)
	ZEND_ARG_TYPE_INFO(0, title, IS_STRING, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_cli_get_process_title, 0, 0, IS_STRING, 1)
ZEND_END_ARG_INFO()
