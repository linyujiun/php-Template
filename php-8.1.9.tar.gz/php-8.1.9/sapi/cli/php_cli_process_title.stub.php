<?php

function cli_set_process_title(string $title): bool {}

function cli_get_process_title(): ?string {}
